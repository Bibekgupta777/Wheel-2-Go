from django.urls import path
from ecommerceapp import views
from django.urls import path, include



urlpatterns = [
    path('',views.index,name="index"),
    path('contact Us',views.contact,name="Contact Us"),
    path('about',views.about,name="about"),
    path('auth/',include('auth_app.urls'))

]
