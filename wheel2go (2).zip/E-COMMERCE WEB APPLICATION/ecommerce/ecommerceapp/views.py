from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from.models import Contact
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login,logout
from django.shortcuts import render


# Create your views here.
def index(request):

        return render(request,"index.html")




def about(request):
    return render(request,"about.html")

def SignupPage(request):
    if request.method=='POST':
        fname=request.POST.get('fullname')
        uname=request.POST.get('username')
        email=request.POST.get('email')
        number=request.POST.get('phoneNumber')
        pass1=request.POST.get('password')
        pass2=request.POST.get('confirmPassword')
        if pass1!=pass2:
            return HttpResponse("your passwords are not same")
        else:

         my_user=User.objects.create_user(uname,email,number,)
         my_user.save()
         return redirect('login.html')
        
     
       
     
    

    return render(request,"signup.html")

def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('mainpage')
        else:
            return HttpResponse("username or passowrd is incorrect")

    return render(request,"login.html")


def homepage(request):
    return render(request,"mainpage.html")

def user(request):
    return render(request,"userprofilee.html")

def contact(request):
    if request.method=="POST":
         contact=Contact
         name=request.POST.get("name")
         email=request.POST.get("email")
         subject=request.POST.get("subject")
         contact.name=name
         contact.email=email
         contact.subject=subject
         contact.save()

         return HttpResponse("thanks for contacting us...")
         

    return render(request,"contactus.html")


def aboutus(request):
    return render(request,"aboutUs.html")

def billinginfo(request):
    return render(request,"billing info.html")


def home(request):
    return render(request,"home.html")

def booking(request):
    return render(request,"booking history.html")



def resetpass(request):
    return render(request,"resetpassword.html")


def customer(request):
    return render(request,"customersupport.html")




def payment(request):
    return render(request,"paymenthistory.html")






from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# from.forms import UpdateUserForm, UpdateProfileForm



