from django.contrib import admin
from ecommerceapp.models import Contact


# Register your models here.
from .models import Contact
admin.site.register(Contact)