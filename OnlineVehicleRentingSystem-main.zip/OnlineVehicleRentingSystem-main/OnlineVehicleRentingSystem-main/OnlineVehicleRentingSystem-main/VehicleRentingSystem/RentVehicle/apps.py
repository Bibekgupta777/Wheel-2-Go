from django.apps import AppConfig


class RentvehicleConfig(AppConfig):
    name = 'RentVehicle'
