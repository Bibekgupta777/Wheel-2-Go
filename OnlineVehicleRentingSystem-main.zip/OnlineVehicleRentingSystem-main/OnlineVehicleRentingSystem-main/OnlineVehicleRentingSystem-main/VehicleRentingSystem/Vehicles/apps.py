from django.apps import AppConfig


class VehiclesConfig(AppConfig):
    name = 'Vehicles'
