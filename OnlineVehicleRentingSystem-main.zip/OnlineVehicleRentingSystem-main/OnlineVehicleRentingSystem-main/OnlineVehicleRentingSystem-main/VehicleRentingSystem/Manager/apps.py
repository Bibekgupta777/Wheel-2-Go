from django.apps import AppConfig


class ManagerConfig(AppConfig):
    name = 'Manager'
